<!DOCTYPE html>
<html lang="en">
<head>
<title>Maton Sytech Technologies</title>
<LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div class="header">

  <h1>Maton Sytech Technologies</h1>
  <p> "The Core of  innovation & technology"</p>
</div>

<div class="navbar">
<a href="main.php"class="active">Main menu</a>
  <a href="about.php">About us</a>
  <a href="mission.php">Mission</a>
  <a href="vision.php">Vision</a>
  <a href="employee.php" >Available Techs & Salary</a>
  <a href="logout.php">Logout</a>  
</div>


  <div class="main">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<div class="main">

  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div class="header">
  <h2>MISSION</h2>
  <P>To assist and rectify all matters from our clients be it service support matters which require  innovation and critical thinking.
  To align with Government of Zimbabwe strategic planning of ICT to the whole nation by 2030.</p>
</div>


</body>
</html>



</div>


<div class="footer">
  <h2>CONTACT US</h2>
 

<p>
<img src="network.jpg" style="width:100%"><br><br>

<p><strong> 45 Harare Street ,Zimbabwe </strong></p>
  <p><strong> Tel: +263 73 462 2923 </strong></p>
  <p><strong> Email: lmatondora@gmail.co.zw </strong></p>
  
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
</head>
<body>

<h2>follow us on our social media</h2>

<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>

<a href="#" class="fa fa-linkedin"></a>

<a href="#" class="fa fa-instagram"></a>

      
  
  
  
</div>

</body>
</html>
