<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
/*if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}  */
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
    <style>
        body{ font: 14px sans-serif; text-align: center; }
    </style>
</head>
<body>
<div class="header">

 <h1>Maton Sytech Technologies</h1>
  <p> "The Core of  innovation & technology"</p>
</div>

<div class="navbar">
  
   <a href="about.php"class="active">About</a>  
   <a href="mission.php">Mission</a>
  <a href="vision.php">Vision</a>
  <a href="employee.php" >Available Techs & Salary</a>
<a href="reset-password.php">Reset Password</a>  
  <?php 

if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] == true){
	 echo '<a href="logout.php">Logout</a>';
}else
{
echo'<a href="login.php">Login</a>';
}
	 ?>   
</div>


  <div class="main">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<div class="main">

  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">


</div>

<div class="header">
  <h2>MISSION</h2>
  <P>To exceed the anticipation of our clients in service provision and product innovation so that customer satisfaction and retention is achieved.
  To overwhelmingly and optimistically influence the shape of Zimbabwe’s ICT services and beyond.</p>
</div>




<div class="footer">
  <h2>CONTACT US</h2>
 

<p>
<img src="computer rep.jpg" alt="" ><br><br>

<p><strong> 45 Harare Street ,Zimbabwe </strong></p>
  <p><strong> Tel: +263 73 462 2923 </strong></p>
  <p><strong> Email: lmatondora@gmail.co.zw </strong></p>
  
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>


<h2>follow us on our social media</h2>

<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>

<a href="#" class="fa fa-linkedin"></a>

<a href="#" class="fa fa-instagram"></a>

      
    
  
</div>

</body>
</html>
