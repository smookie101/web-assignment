<!DOCTYPE html>
<html lang="en">
<head>
<title>Maton Sytech Technologies</title>
<LINK REL=StyleSheet HREF="style.css" TYPE="text/css" MEDIA=screen>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div class="header">

  
  <h1>Maton Sytech Technologies</h1>
  <p> "The Core of  innovation & technology"</p>
</div>

<div class="navbar">
  <a href="main.php"class="active">Main Menu</a>
  <a href="about.php">About us</a>
   <a href="employee.php" >Available Techs & Salary</a>
  <a href="mission.php">Mission</a>
  <a href="vision.php"> Vision</a>
 
  
</div>

<div class="row">
  <div class="side">
    <h2>About Us</h2>
    Maton Sytech Technologies Limited was initiated in Janauary 2017 and main focuses in hardware maintainance and repair,
	website deverlopment ,  graphic designing, Networking, as well as  software isues.The company also assist those embarking
	in both small and large projects in high schools and universities.<br><br>In 2019 the company managed to diversify into product 
	supply <br><br>The major aim is to provide quality orientated products and services our clientelle.
	The company’s youthful passion promises longevity in innovative service provision.<br><br> Maton Sytech Technologies
	aims to provide technology based solutions to enterprises, government, and other private and public organizations within 
	harare and the rest of the world.<br><br> Maton Sytech Technologies Ltd main office is located	in Harare, along Harare Street.
  </div>
  <div class="main">
  <meta name="viewport" content="width=device-width, initial-scale=1">



<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 4</div>
  <img src="computer rep.jpg" style="width:100%">
  <div class="text">Computer Repairs and Maintenance, Software and Antivirus Supply ,IT Products Supply</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 4</div>
  <img src="network.jpg" style="width:100%">
  <div class="text">Consultancy ,Management Information systems anad support</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 4</div>
  <img src="hard1.jpg" style="width:100%">
  <div class="text">Website Hosting ,Email Hosting ,Network Design and Installation</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 4</div>
  <img src="hard4.jpg" style="width:100%">
  <div class="text">Website Hosting ,Email Hosting ,Network Design and Installation</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
   <span class="dot"></span> 
</div>
<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 4000); // Change image every 2 seconds
}
</script>

  
      </div>
</div>
<div class="main">

  <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div class="header">
  <h2>DESCRIPTION OF OUR PRODUCTS AND SERVICES</h2>
  <P>Maton Sytech Technologies Ltd is one of the leading ICT Company that provides world class Information and Communication Technology 
  (ICT) products and services to companies, individuals, organizations, institutions and many more.  We have professionals who are 
  innovative and creative in providing these classic ICT products and services in Zimbabwe and abroad. </p>
</div>


<div class="row">
  <div class="column">
    <h2>Software Development and Web Designing</h2>
    <p>
 We develop software of your choice that your organization, company, institution might be in need of.
 We have professional staff in software development either standalone software or web based software to manage your day to day
 transactions and activities.<br><br> we develop inventory systems, point of sale software, databases, Electronic Learning systems,
 student management systems just to mention a few.<br><br>
 Maton Sytech Technologies is a company that develops world class websites for your company so that you can expose your brand 
 to the world for wide recognition.<br><br> We develop static as well as dynamic websites that you may be interested in to 
 meet and suite your needs as our client.</p>
  </div>
  
  <div class="column">
    <h2>Consultancy services and Training</h2>
    <p>We provide Training in different software that you need your employees to be trained in. Some of the software that we 
	provide training include Joomla, Wordpress, Drupal for Website Design and Development, Software Development, Web Programming, 
	Graphics Packages for example Adobe Photoshop and other programming languages for example PHP, CSSS, HTML
<br><br>We provide ICT related consultancy services to companies’ individuals, Organizations, institutions and many more.</p>
  </div>
  
  <div class="column">
    <h2>Computer Repair and maintenance and Hardware, Software Supply and antivirus Installation </h2>
    <p>We Repair and maintain computers. When your computer has a hardware or software problem we 
provide repair services, cleaning the computer from viruses and installing necessary software for smooth running of your computer every day.
<br><br>
We supply different software that your company needs at any time like Anti viruses, Office Packages, 
Windows Operating systems, SAGE Line 50, Statistical Packages and many others your company needs anytime</p>
</div>

</body>
</html>



</div>



<div class="footer">
  <h2>CONTACT US</h2>
 

<p>
<img src="" alt="" ><br><br>

<p><strong> 45 Harare Street ,Zimbabwe </strong></p>
  <p><strong> Tel: +263 73 462 2923 </strong></p>
  <p><strong> Email: lmatondora@gmail.co.zw </strong></p>
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>

</head>
<body>

<h2>follow us on our social media</h2>

<!-- Add font awesome icons -->
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>

<a href="#" class="fa fa-linkedin"></a>

<a href="#" class="fa fa-instagram"></a>

      
    
  
</div>

</body>
</html>
